

class City {

  final String cityname;
   String choose;
   dynamic color;

  // 생성자
  City({
    required this.cityname,
    required this.choose,
    required this.color,
  });

}

