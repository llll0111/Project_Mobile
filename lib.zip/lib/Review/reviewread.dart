import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


class ReviewRead extends StatefulWidget {
  late String number;
  late String nick = "";

  ReviewRead({required this.number, required this.nick});

  @override
  State<ReviewRead> createState() => _ReviewReadState();
}

class _ReviewReadState extends State<ReviewRead> {
  late String number;
  late String nick = "";

  @override
  void initState() {
    super.initState();
    nick = widget.nick;
    number = widget.number;
  }

  final Stream<QuerySnapshot> cstableStream =
      FirebaseFirestore.instance.collection('Review').snapshots();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
        stream: cstableStream,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            print('Something went Wrong');
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          final List storedocs = [];
          late String today;
          List<String> image=[];
          snapshot.data!.docs.map((DocumentSnapshot document) {
            Map a = document.data() as Map<String, dynamic>;
            if(a['number'] == number){
              storedocs.add(a);
              Timestamp ss = a['date'];
              today = DateFormat('yyyy/MM/dd/kk:mm').format(ss.toDate());
              String img = storedocs[0]["image"]??null;
               image =  img.split(',');
            }

          }).toList();

          return Scaffold(
            appBar: AppBar(
              title: Text('GO TRIP'),
              centerTitle: true,
              foregroundColor: Colors.black,
              backgroundColor: Colors.purple[100],
            ),
            body: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Column(children: <Widget>[
                  Center(
                    child: Container(
                      padding: const EdgeInsets.only(
                        top: 20,
                      ),
                      child: Text('한번쯤은 가볼만한곳',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20,
                          )),
                    ),
                  ),
                  Container(
                      width: 380,
                      child: Divider(color: Colors.grey, thickness: 1.0)),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 10, left: 10),
                          child: Row(
                           children: [
                             Container(
                               child: Text(
                                 '제목: ${storedocs[0]['reviewTitle']}',
                                 style: TextStyle(
                                   fontSize: 20,
                                   fontWeight: FontWeight.bold,
                                 ),
                               ),
                             ),
                           ],
                          )
                        ),
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Container(
                              child: Text('작성자: $nick',
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  )),
                            ),
                            )

                          ],
                        ),
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Container(
                                child: Text('작성날짜: $today',
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    )),
                              ),
                            )

                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10, left: 10),
                          child: Center(
                            child: Container(
                                width: 300,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Flexible(
                                        child: RichText(
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 5,
                                          strutStyle: StrutStyle(fontSize: 16.0),
                                          text: TextSpan(
                                              text:storedocs[0]['reviewCon'],
                                              style: TextStyle(
                                                  color: Colors.black,
                                                  height: 1.4,
                                                  fontSize: 16.0,
                                                  fontFamily: 'NanumSquareRegular')),
                                        )),
                                  ],
                                )),
                          )
                        ),
                        if(image.length >=0)...[
                          Padding(
                            padding: EdgeInsets.only(top: 10),
                            child: Center(
                              child: Column(
                                children: [
                                  for(int a=0; a<image.length-1;a++)...[
                                    Image.network(image[a])
                                  ]
                                ],
                              ),
                            ),
                          )
                        ]
                      ],
                    ),
                  ),
                  // SizedBox(
                  //   width: 380,
                  //   child: TextField(
                  //     readOnly: true,
                  //     keyboardType: TextInputType.multiline,
                  //     decoration: InputDecoration(
                  //       hintText: "내용을 입력해주세요",
                  //       border: OutlineInputBorder(),
                  //       contentPadding: EdgeInsets.symmetric(vertical: 80),
                  //     ),
                  //     style: TextStyle(fontSize: 10),
                  //   ),
                  // ),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10, left: 10),
                      child: Container(
                        child: Text('댓글작성',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            )),
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 380,
                    child: TextField(
                      keyboardType: TextInputType.multiline,
                      decoration: InputDecoration(
                        hintText: "내용을 입력해주세요",
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(vertical: 20),
                      ),
                      style: TextStyle(fontSize: 10),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              primary: Colors.purple,
                              textStyle: const TextStyle(fontSize: 15)),
                          onPressed: () {},
                          child: Text('등록')),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Container(
                      padding: const EdgeInsets.only(top: 10, left: 10),
                      child: Text('댓글',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  Container(
                      width: 380,
                      child: Divider(color: Colors.grey, thickness: 1.0)),
                ]),
              ),
            ),
          );

          // return Scaffold(
          //   appBar: AppBar(
          //     title: const Text('Go Trip'),
          //     foregroundColor: Colors.black,
          //     centerTitle: true,
          //     backgroundColor: Colors.purple[100],
          //   ),
          //   body: SafeArea(
          //       child: Column(
          //         children: [
          //           const Padding(padding: EdgeInsets.only(top: 12)),
          //           Center(
          //             child: Text(
          //               "사람들이 추천하는 가볼만한곳",
          //               style: TextStyle(
          //                 fontSize: 20,
          //                 fontWeight: FontWeight.w200,
          //               ),
          //             ),
          //           ),
          //           const Padding(padding: EdgeInsets.only(top: 12)),
          //           Expanded(
          //             child: ListView.builder(
          //                 itemCount: storedocs.length,
          //                 itemBuilder: (context, index) {
          //                   //return Card(
          //                   //child:
          //                   return Row(
          //                     //mainAxisAlignment: MainAxisAlignment.spaceAround,
          //                     children: [
          //                       const Padding(
          //                           padding: EdgeInsets.fromLTRB(0, 12, 0, 0)),
          //                       TextButton(
          //                         onPressed: () {
          //                           Get.to(ReviewRead(number: storedocs[index]['number'], nick: nick,));
          //                         },
          //                         child: Text(
          //                           "${storedocs[index]['reviewTitle']}",
          //                           style: TextStyle(
          //                             fontSize: 18,
          //                           ),
          //                         ),
          //                       ),
          //                     ],
          //                   );
          //                   //);
          //                 }),
          //           ),
          //         ],
          //       )),
          // );
        });
    //  @override
    //  Widget build(BuildContext context) {
    //   return StreamBuilder<QuerySnapshot>(
    //       stream: cstableStream,
    //       builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
    //     if (snapshot.hasError) {
    //       print('Something went Wrong');
    //     }
    //     if (snapshot.connectionState == ConnectionState.waiting) {
    //       return const Center(
    //         child: CircularProgressIndicator(),
    //       );
    //     }
    //
    //     final List storedocs = [];
    //     snapshot.data!.docs.map((DocumentSnapshot document) {
    //       Map a = document.data() as Map<String, dynamic>;
    //       storedocs.add(a);
    //       a['id'] = document.id;
    //       print(storedocs[0]);
    //       print(storedocs);
    //     }).toList();

    // return Scaffold(
    //   appBar: AppBar(
    //     title: Text('GO TRIP'),
    //     centerTitle: true,
    //     foregroundColor: Colors.black,
    //     backgroundColor: Colors.purple[100],
    //   ),
    //
    //   body:
    //
    //   GestureDetector(
    //     onTap: () => FocusScope.of(context).unfocus(),
    //
    //     child: SingleChildScrollView(
    //
    //       scrollDirection: Axis.vertical,
    //
    //       child: Column(children:<Widget>[
    //
    //         Center(
    //           child: Container(
    //             padding: const EdgeInsets.only(top:20,),
    //             child: Text(
    //                 '한번쯤은 가볼만한곳',
    //                 textAlign: TextAlign.center,
    //                 style: TextStyle(fontSize: 20,)
    //             ),
    //           ),
    //         ),
    //
    //         Container(
    //             width: 380,
    //             child: Divider(color: Colors.grey, thickness: 1.0)),
    //
    //         Align(
    //           alignment: Alignment.bottomLeft,
    //           child: Column(
    //             children: [
    //               Padding(
    //                 padding: const EdgeInsets.only(top: 10, left: 10),
    //                 child: Container(
    //                   child: Text(
    //                     '제목: ',
    //                     style: TextStyle(fontSize: 20, fontWeight:FontWeight.bold,),
    //                   ),
    //                 ),
    //               ),
    //
    //               Padding(
    //                 padding: const EdgeInsets.only(top: 10, left: 10),
    //                 child: Container(
    //                   child: Text(
    //                       '작성자: ',
    //                       style: TextStyle(fontSize: 15, fontWeight:FontWeight.bold,)
    //                   ),
    //                 ),
    //               ),
    //
    //               Padding(
    //                 padding: const EdgeInsets.only(top: 10, left: 10),
    //                 child: Container(
    //                   child: Text(
    //                       '작성날짜: ',
    //                       style: TextStyle(fontSize: 15, fontWeight:FontWeight.bold,)
    //                   ),
    //                 ),
    //               ),
    //
    //               Padding(
    //                 padding: const EdgeInsets.only(top: 10, left: 10),
    //                 child: Container(
    //                   child: Text(
    //                       '글내용: ',
    //                       style: TextStyle(fontSize: 15, fontWeight:FontWeight.bold,)
    //                   ),
    //                 ),
    //               ),
    //             ],
    //           ),
    //         ),
    //
    //         SizedBox(
    //           width: 380,
    //           child: TextField(
    //             readOnly: true,
    //             keyboardType: TextInputType.multiline,
    //             decoration: InputDecoration(
    //               hintText: "내용을 입력해주세요",
    //               border: OutlineInputBorder(),
    //               contentPadding: EdgeInsets.symmetric(vertical: 80),
    //             ),
    //             style: TextStyle(fontSize: 10),
    //           ),
    //
    //         ),
    //
    //         Align(
    //           alignment: Alignment.bottomLeft,
    //           child: Padding(
    //             padding: const EdgeInsets.only(top: 10, left: 10),
    //             child: Container(
    //               child: Text(
    //                   '댓글작성',
    //                   style: TextStyle(fontSize: 15, fontWeight:FontWeight.bold,)
    //               ),
    //             ),
    //           ),
    //         ),
    //
    //         const SizedBox(
    //           width: 380,
    //           child: TextField(
    //             keyboardType: TextInputType.multiline,
    //             decoration: InputDecoration(
    //               hintText: "내용을 입력해주세요",
    //               border: OutlineInputBorder(),
    //               contentPadding: EdgeInsets.symmetric(vertical: 20),
    //             ),
    //             style: TextStyle(fontSize: 10),
    //           ),
    //
    //         ),
    //
    //         Align(
    //           alignment: Alignment.bottomRight,
    //           child: Padding(
    //             padding: const EdgeInsets.only(right: 10),
    //             child: ElevatedButton(
    //                 style: ElevatedButton.styleFrom(
    //                     primary: Colors.purple,
    //                     textStyle: const TextStyle(fontSize: 15)
    //                 ),
    //                 onPressed: (){},
    //                 child: Text('등록')),
    //           ),
    //         ),
    //
    //         Align(
    //           alignment: Alignment.bottomLeft,
    //           child: Container(
    //             padding: const EdgeInsets.only(top: 10, left: 10),
    //             child: Text('댓글',
    //                 style:
    //                 TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
    //           ),),
    //
    //
    //
    //         Container(
    //             width: 380,
    //             child: Divider(color: Colors.grey, thickness: 1.0)),
    //
    //
    //
    //
    //
    //
    //       ]),
    //
    //     ),
    //   ),
    //
    // );
    //)}
  }
}
