// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:untitled/Review/reviewread.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';
// import 'package:firebase_storage/firebase_storage.dart';
//
//
// class ReviewUpload2 extends StatefulWidget {
//   const ReviewUpload2({Key? key}) : super(key: key);
//
//   @override
//   _ReviewUploadState createState() => _ReviewUploadState();
// }
//
// class _ReviewUploadState extends State<ReviewUpload2> {
//
//   FirebaseFirestore fire = FirebaseFirestore.instance;
//
//   TextEditingController titleController = TextEditingController();
//
//   TextEditingController contentController = TextEditingController();
//
//
//   String reviewTitle="";
//   String reviewCon="";
//
//   String imageUrl='';///////////
//
//   // final ImagePicker _picker = ImagePicker();
//   // List<XFile> _pickedImgs = [];
//   // String uniqueFileName = DateTime.now().millisecondsSinceEpoch.toString();
//
//
//   // @override
//   // void initState(){
//   //   super.initState();
//   // }
//   //
//   //
//   //
//   // Future<void> _pickImg() async {
//   //   final List<XFile>? images = await _picker.pickMultiImage();
//   //   if (images != null) {
//   //     setState(() {
//   //       _pickedImgs = images;
//   //     });
//   //   }
//   // }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//
//     // bool isPadMode = MediaQuery.of(context).size.width > 700;
//     // List<Widget> _boxContents = [
//     //   IconButton(
//     //       onPressed: () {
//     //         _pickImg();
//     //       },
//     //       icon: Container(
//     //           alignment: Alignment.center,
//     //           decoration: BoxDecoration(
//     //               color: Colors.white.withOpacity(0.6), shape: BoxShape.circle),
//     //           child: Icon(
//     //             CupertinoIcons.camera,
//     //             color: Theme.of(context).colorScheme.primary,
//     //           ))),
//     //   /* Container(),
//     //   Container(),*/
//     //   _pickedImgs.length <= 2
//     //       ? Container()
//     //       : FittedBox(
//     //       child: Container(
//     //           padding: EdgeInsets.all(6),
//     //           decoration: BoxDecoration(
//     //               color: Colors.white.withOpacity(0.6),
//     //               shape: BoxShape.circle),
//     //           child: Text(
//     //             '+${(_pickedImgs.length - 2).toString()}',
//     //             style: Theme.of(context)
//     //                 .textTheme
//     //                 .subtitle2
//     //                 ?.copyWith(fontWeight: FontWeight.w800),
//     //           ))),
//     // ];
//
//     return Scaffold(
//       resizeToAvoidBottomInset: true,
//       appBar: AppBar(
//         title: Text('GO TRIP'),
//         centerTitle: true,
//         foregroundColor: Colors.black,
//         backgroundColor: Colors.purple[100],
//       ),
//
//       body: GestureDetector(
//         onTap: () => FocusScope.of(context).unfocus(),
//         child: SingleChildScrollView(
//
//           scrollDirection: Axis.vertical,
//
//           child: Column(children: <Widget>[
//
//             Container(
//               padding: const EdgeInsets.only(top: 30),
//               child: Text(
//                   '한번쯤은 가볼만한곳',
//                   style: TextStyle(fontSize: 20,)
//               ),
//             ),
//
//             Padding(
//               padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
//               child: TextField
//                 (controller: titleController,
//                 decoration: InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: '제목',
//                   hintText: '내용을 입력해주세요',
//                 ),
//                 onChanged: (value) {
//                   setState(() {
//                     reviewTitle = value;
//                   });
//                 },
//               ),
//             ),
//
//             Padding(
//               padding: const EdgeInsets.only(top: 30, right: 300),
//               child: Text(
//                   '글입력',
//                   textAlign: TextAlign.left,
//                   style: TextStyle(fontSize: 15,)
//               ),
//             ),
//
//             Padding(
//               padding: const EdgeInsets.only(top: 20, left: 20, right: 20),
//               child: Column(
//                 children: [
//                   TextField(
//                     controller: contentController,
//                     keyboardType: TextInputType.multiline,
//                     maxLines: 4,
//                     decoration: InputDecoration(
//                         border: OutlineInputBorder(),
//                         hintText: "내용을 입력해주세요",
//                         focusedBorder: OutlineInputBorder(
//                             borderSide: BorderSide()
//                         )
//                     ),
//                     onChanged: (value) {
//                       setState(() {
//                         reviewCon = value;
//                       });
//                     },
//                   ),
//
//                   /* TextField
//                 (controller: _csconCon,
//
//                 decoration: InputDecoration(
//                     border: OutlineInputBorder(), labelText: '내용을 입력해주세요'),
//
//               ),
//             ),*/
//                   Padding(
//                     padding: const EdgeInsets.only(top: 30, right: 250),
//                     child: Text(
//                         '사진등록하기',
//                         textAlign: TextAlign.left,
//                         style: TextStyle(fontSize: 15,)
//                     ),
//                   ),
//
//                   // SizedBox(
//                   //     width: 400,
//                   //     height: 200,
//                   //     child: GridView.count(
//                   //       padding: EdgeInsets.all(2),
//                   //       crossAxisCount: 2,
//                   //       mainAxisSpacing: 5,
//                   //       crossAxisSpacing: 5,
//                   //       children: List.generate(
//                   //           2, (index) => DottedBorder(
//                   //           child: Container(
//                   //             child: Center(child: _boxContents[index]),
//                   //           ),
//                   //           color: Colors.grey,
//                   //           dashPattern: [5,3],
//                   //           borderType: BorderType.RRect,
//                   //           radius: Radius.circular(10))).toList(),
//                   //     )),
//
//
//                   Padding(
//                     padding: const EdgeInsets.only(right: 250),
//                     child: IconButton(
//                       onPressed: () async{
//                         ImagePicker imagePicker = ImagePicker();
//                         XFile? file = await imagePicker.pickImage(source: ImageSource.gallery);
//                         print('${file?.path}');
//
//                         if(file==null) return;
//
//                         String uniqueFileName = DateTime.now().millisecondsSinceEpoch.toString();
//
//                         //참조할 이미지 경로 얻기
//                         Reference referenceRoot = FirebaseStorage.instance.ref();
//                         Reference referenceDirImages = referenceRoot.child('profile'); // firebase storage 폴더명 : profile
//
//                         //저장할 이미지 참조 생성
//                         Reference referenceImageToUpload = referenceDirImages.child(uniqueFileName);
//
//                         try{
//                           //파일을 저장
//                           await referenceImageToUpload.putFile(File(file!.path));
//                           //성공시 다운로드 URL get
//                           imageUrl = await referenceImageToUpload.getDownloadURL();
//                         }catch(error){}
//
//
//                       },
//                       icon: Icon(Icons.add_circle),
//                       iconSize: 80,
//                       color: Colors.grey[300],
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: ElevatedButton(
//
//                         style: ElevatedButton.styleFrom(
//                             primary: Colors.purple,
//                             minimumSize: Size(200, 50),
//                             textStyle: const TextStyle(fontSize: 20)
//                         ),
//
//                         onPressed: () async{
//                           //Get.toNamed('/');
//                           if(imageUrl.isEmpty){
//                             ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('이미지를 업로드 해주세요')));
//                             return;
//                           }
//
//
//                           Get.to(ReviewRead());
//                           fire.collection('Review').doc(reviewTitle).set({
//
//                             "reviewTitle": reviewTitle,
//                             "reviewCon": reviewCon,
//                             "image":imageUrl,
//                           });
//
//                         },
//                         child: Text('글등록')),
//                   ),
//
//
//                 ],
//               ),
//             ),
//           ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
