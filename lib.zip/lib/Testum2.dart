import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:get/get.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/Test112.dart';
import 'package:untitled/Testim1.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '리뷰게시판',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ImageUploader(),
      debugShowCheckedModeBanner: false,
      //initialRoute: '/',
      // getPages: [
      //   //LIst, <dynamic>
      //   //GetPage(name: '/', page: () => ReviewUpload2()),
      //   GetPage(name: '/', page: () => ImageUploader()),
      //
      //   //GetPage(name: '/insert', page: () => CsUpload()),
      // ],
    );
  }
}