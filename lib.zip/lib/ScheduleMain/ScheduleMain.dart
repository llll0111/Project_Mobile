import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:untitled/mainControl.dart';

import '../mainpage.dart';

class ScheduleMain extends StatefulWidget {
  late final String nick;
  late final String start;
  late final String end;
  late final String city;

  ScheduleMain({
    required this.nick,
    required this.start,
    required this.end,
    required this.city
  });

  @override
  _CheckState createState() => _CheckState();
}

class _CheckState extends State<ScheduleMain> {
  late final String nick;
  late final String start;
  late final String end;
  late final String city;
  late List<String> cityss = city.split(' ');
  Completer<GoogleMapController> _controller = Completer();
  // double startmap = 37.5667;
  // double endmap = 126.9784;
  late CameraPosition _currentPosition;
  late List<Marker> markers;


  @override
  void initState() {
    super.initState();
    nick = widget.nick;
    start = widget.start;
    end = widget.end;
    city = widget.city;
  }
  late Stream<QuerySnapshot> cstableStream =
  FirebaseFirestore.instance.collection('CityPosition')
      .where("city",isEqualTo: cityss[0])
      .snapshots();
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
        stream: cstableStream,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            print('Something went Wrong');
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          double lat=0;
          double long=0;
          snapshot.data!.docs.map((DocumentSnapshot document) {
            Map a = document.data() as Map<String, dynamic>;
            lat = double.parse(a["lat"]);
            long = double.parse(a["lon"]);
            markers = [
              (Marker(position: LatLng(lat, long), markerId: MarkerId(cityss[0])))
            ];
          }).toList();

          return Scaffold(
            appBar: AppBar(
              title: Text("나의 일정"),
              centerTitle: true,
              backgroundColor: Colors.deepPurple,
              leading: IconButton(
                  onPressed: () {
                    Get.off(() => MainPage(nick: nick));
                  },
                  icon: Icon(Icons.arrow_back)),
            ),
            body: Column(
              children: [

                Padding(padding: EdgeInsets.only(top: 20)),
                Center(
                  child: Container(
                    width: 360,
                    height: 140,
                    child: GoogleMap(
                      zoomGesturesEnabled:true,
                      zoomControlsEnabled: false,
                      initialCameraPosition: CameraPosition(
                        target: LatLng(lat, long),
                        zoom: 12, //확대
                      ),
                      markers: markers.toSet(),
                      onMapCreated: (GoogleMapController controller) {
                        controller.animateCamera(CameraUpdate.newLatLng(LatLng(lat,long)));
                        _controller.complete();
                      },
                    ),
                  ),
                )

              ],

            )
          );
        }
        );
    // Widget sss(){
    //   return ListView.builder(
    //       itemCount: ,
    //       itemBuilder:
    //   );
    //}

  }


}
